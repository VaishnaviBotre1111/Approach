﻿using System;
using System.Collections.Generic;

namespace AllProject.Models;

public partial class User
{
    public int UId { get; set; }

    public string UName { get; set; } = null!;

    public string UEmail { get; set; } = null!;

    public string? UPassword { get; set; }

    public string? UAddress { get; set; }
}
