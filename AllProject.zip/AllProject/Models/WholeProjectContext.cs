﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace AllProject.Models;

public partial class WholeProjectContext : DbContext
{
    public WholeProjectContext()
    {
    }

    public WholeProjectContext(DbContextOptions<WholeProjectContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Admin> Admins { get; set; }

    public virtual DbSet<Passenger> Passengers { get; set; }

    public virtual DbSet<Reservation> Reservations { get; set; }

    public virtual DbSet<Train> Trains { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder){
        if(!optionsBuilder.IsConfigured){
            optionsBuilder.UseSqlServer("Data Source=LIN-PF1QEPJN; Initial Catalog=WholeProject;Integrated Security=True;TrustServerCertificate=True");
        }
    }
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
      //  => optionsBuilder.UseSqlServer("Data Source=LIN-PF1QEPJN; Initial Catalog=WholeProject;Integrated Security=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Admin>(entity =>
        {
            entity.ToTable("admin");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.Name)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.Password)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("password");
        });

        modelBuilder.Entity<Passenger>(entity =>
        {
            entity.HasKey(e => e.PId);

            entity.ToTable("passenger");

            entity.Property(e => e.PId).HasColumnName("p_id");
            entity.Property(e => e.PAddharNo).HasColumnName("p_addhar_no");
            entity.Property(e => e.PAddress)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("p_address");
            entity.Property(e => e.PAge).HasColumnName("p_age");
            entity.Property(e => e.PDob).HasColumnName("p_dob");
            entity.Property(e => e.PEmail)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("p_email");
            entity.Property(e => e.PGender)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("p_gender");
            entity.Property(e => e.PMobileNo).HasColumnName("p_mobile_no");
            entity.Property(e => e.PName)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("p_name");
            entity.Property(e => e.RId).HasColumnName("r_id");
            entity.Property(e => e.SeatNo).HasColumnName("seat_no");
        });

        modelBuilder.Entity<Reservation>(entity =>
        {
            entity.HasKey(e => e.RId);

            entity.ToTable("reservations");

            entity.Property(e => e.RId).HasColumnName("r_id");
            entity.Property(e => e.BDate).HasColumnName("b_date");
            entity.Property(e => e.BStatus)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("b_status");
            entity.Property(e => e.NoOftickets).HasColumnName("no_oftickets");
            entity.Property(e => e.PaymentStatus)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("payment_status");
            entity.Property(e => e.TId).HasColumnName("t_id");
            entity.Property(e => e.TotalPrice).HasColumnName("total_price");
            entity.Property(e => e.UId).HasColumnName("u_id");
        });

        modelBuilder.Entity<Train>(entity =>
        {
            entity.HasKey(e => e.TId);

            entity.ToTable("trains");

            entity.Property(e => e.TId).HasColumnName("t_id");
            entity.Property(e => e.DepartureDate).HasColumnName("departure_date");
            entity.Property(e => e.TAddeddate).HasColumnName("t_addeddate");
            entity.Property(e => e.TArrivaltime)
                .HasColumnType("datetime")
                .HasColumnName("t_arrivaltime");
            entity.Property(e => e.TDeparturetime)
                .HasColumnType("datetime")
                .HasColumnName("t_departuretime");
            entity.Property(e => e.TDestination)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("t_destination");
            entity.Property(e => e.TFare).HasColumnName("t_fare");
            entity.Property(e => e.TName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("t_name");
            entity.Property(e => e.TSource)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("t_source");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UId);

            entity.Property(e => e.UId)
                .ValueGeneratedNever()
                .HasColumnName("u_id");
            entity.Property(e => e.UAddress)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("u_address");
            entity.Property(e => e.UEmail)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("u_email");
            entity.Property(e => e.UName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("u_name");
            entity.Property(e => e.UPassword)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("u_password");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
