﻿using System;
using System.Collections.Generic;

namespace AllProject.Models;

public partial class Passenger
{
    public int PId { get; set; }

    public int RId { get; set; }

    public string PName { get; set; } = null!;

    public string PEmail { get; set; } = null!;

    public int PAge { get; set; }

    public string? PGender { get; set; }

    public long PAddharNo { get; set; }

    public DateOnly PDob { get; set; }

    public long PMobileNo { get; set; }

    public string? PAddress { get; set; }

    public int SeatNo { get; set; }
}
