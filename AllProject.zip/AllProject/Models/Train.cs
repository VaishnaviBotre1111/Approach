﻿using System;
using System.Collections.Generic;

namespace AllProject.Models;

public partial class Train
{
    public int TId { get; set; }

    public string TName { get; set; } = null!;

    public string TSource { get; set; } = null!;

    public string TDestination { get; set; } = null!;

    public DateOnly DepartureDate { get; set; }

    public DateTime TArrivaltime { get; set; }

    public DateTime TDeparturetime { get; set; }

    public int TFare { get; set; }

    public DateOnly TAddeddate { get; set; }
}
