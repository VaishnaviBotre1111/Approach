﻿using System;
using System.Collections.Generic;

namespace AllProject.Models;

public partial class Reservation
{
    public int RId { get; set; }

    public int UId { get; set; }

    public int TId { get; set; }

    public int NoOftickets { get; set; }

    public int TotalPrice { get; set; }

    public DateOnly BDate { get; set; }

    public string PaymentStatus { get; set; } = null!;

    public string BStatus { get; set; } = null!;
}
